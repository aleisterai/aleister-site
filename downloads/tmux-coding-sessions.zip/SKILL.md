---
name: tmux-coding-sessions
version: 1.0.0
description: |
  Stable tmux session management for long-running AI coding agents on macOS.
  Solves the macOS temp directory reaping problem where agent sockets get
  destroyed mid-session. Provides patterns for spawning, monitoring, and
  scraping output from persistent coding sessions that survive system cleanup.
allowed-tools:
  - Bash
  - Read
  - Write
---

# tmux Coding Sessions: Stable Long-Running Agents

> **This is a prompt skill** — shell patterns and instructions for the agent.

macOS periodically cleans `/tmp` and invalidates socket files. If your coding
agent lives in a tmux session that uses the default socket path, it dies silently.
This skill fixes that.

---

## The Core Problem

Default tmux socket: `/tmp/tmux-{uid}/default`
macOS periodic cleanup: kills this directory while sessions are running
Result: agent mid-task, session gone, work lost

---

## The Fix: Stable Socket Path

Always create tmux sessions with an explicit socket in a stable location:

```bash
# Bad — uses /tmp (gets reaped)
tmux new-session -d -s coding

# Good — uses stable socket
tmux -S ~/.tmux/agent.sock new-session -d -s coding
```

Set this once in your shell config:
```bash
export TMUX_TMPDIR="$HOME/.tmux"
mkdir -p ~/.tmux
```

---

## Session Lifecycle

### Create a coding session

```bash
SESSION="task-$(date +%s)"
mkdir -p ~/.tmux

# Create session with stable socket
tmux -S ~/.tmux/agent.sock new-session -d -s "$SESSION" -x 220 -y 50

# Set working directory
tmux -S ~/.tmux/agent.sock send-keys -t "$SESSION" "cd /path/to/project" Enter

# Verify it's alive
tmux -S ~/.tmux/agent.sock list-sessions
```

### Send a task to the agent

```bash
# Send a command
tmux -S ~/.tmux/agent.sock send-keys -t "$SESSION" "your command here" Enter

# Send multi-line (use heredoc via file)
cat > /tmp/task.sh << 'EOF'
implement the auth middleware
run the tests
report results
EOF
tmux -S ~/.tmux/agent.sock send-keys -t "$SESSION" "bash /tmp/task.sh" Enter
```

### Scrape output

```bash
# Capture current pane content
tmux -S ~/.tmux/agent.sock capture-pane -t "$SESSION" -p

# Capture with history (last 5000 lines)
tmux -S ~/.tmux/agent.sock capture-pane -t "$SESSION" -p -S -5000

# Save to file for analysis
tmux -S ~/.tmux/agent.sock capture-pane -t "$SESSION" -p -S -5000 > /tmp/session-output.txt
```

### Check if session is still running

```bash
if tmux -S ~/.tmux/agent.sock has-session -t "$SESSION" 2>/dev/null; then
    echo "Session alive"
else
    echo "Session dead — restart needed"
fi
```

### Poll for completion signal

```bash
# Agent writes DONE to a file when finished
while true; do
    if [ -f /tmp/task-complete-$SESSION ]; then
        output=$(cat /tmp/task-output-$SESSION)
        echo "Task complete: $output"
        break
    fi
    sleep 5
done
```

---

## Multi-Session Patterns

### Parallel coding agents

```bash
for i in 1 2 3; do
    tmux -S ~/.tmux/agent.sock new-session -d -s "agent-$i"
    tmux -S ~/.tmux/agent.sock send-keys -t "agent-$i" "run subtask-$i.md" Enter
done

# Wait for all
for i in 1 2 3; do
    while tmux -S ~/.tmux/agent.sock has-session -t "agent-$i" 2>/dev/null; do
        sleep 10
    done
    echo "agent-$i done"
done
```

### Named windows for task stages

```bash
SESSION="feature-auth"
tmux -S ~/.tmux/agent.sock new-session -d -s "$SESSION"

# Create named windows for each stage
tmux -S ~/.tmux/agent.sock new-window -t "$SESSION" -n "tests"
tmux -S ~/.tmux/agent.sock new-window -t "$SESSION" -n "impl"
tmux -S ~/.tmux/agent.sock new-window -t "$SESSION" -n "review"

# Run stages in parallel
tmux -S ~/.tmux/agent.sock send-keys -t "$SESSION:tests" "write_tests.sh" Enter
tmux -S ~/.tmux/agent.sock send-keys -t "$SESSION:impl" "implement.sh" Enter
```

---

## Cleanup

```bash
# Kill a specific session
tmux -S ~/.tmux/agent.sock kill-session -t "$SESSION"

# Kill all agent sessions
tmux -S ~/.tmux/agent.sock kill-server

# Clean up stale output files
find /tmp -name "task-*" -mtime +1 -delete
```

---

## Integration with OpenClaw exec tool

When using OpenClaw's exec tool for long-running tasks:

```bash
# Spawn in background, poll later
exec(
  command="tmux -S ~/.tmux/agent.sock send-keys -t my-session 'long_task.sh' Enter",
  background=True
)

# Poll the session output
process(action="poll", sessionId="...", timeout=30000)
```

---

## Troubleshooting

**Session exists but commands don't run**
```bash
# Check if shell is waiting for input
tmux -S ~/.tmux/agent.sock capture-pane -t SESSION -p | tail -5
```

**Socket permission denied**
```bash
chmod 700 ~/.tmux
chmod 600 ~/.tmux/agent.sock
```

**Session lost after sleep/wake**
```bash
# macOS may still clean ~/.tmux on some configs
# Use ~/Library/Application\ Support/tmux/ as fallback
export TMUX_TMPDIR="$HOME/Library/Application Support/tmux"
mkdir -p "$TMUX_TMPDIR"
```
