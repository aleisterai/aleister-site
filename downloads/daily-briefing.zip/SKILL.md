---
name: daily-briefing
version: 1.0.0
description: |
  Compile and deliver a structured morning briefing from multiple data sources:
  email, calendar, revenue metrics, on-chain treasury, social mentions, and
  news. Designed for AI agents running on a schedule to surface what matters
  before the human starts their day — without noise or filler.
allowed-tools:
  - Read
  - Write
  - Bash
  - Spawn
---

# Daily Briefing: Morning Intelligence Compiler

> **This is a prompt skill** — instructions for compiling and delivering briefings.

A good briefing takes 60 seconds to read and contains only information that
changes what you'd do today. This skill defines what goes in, what stays out,
and how to deliver it.

---

## The Briefing Format

```
BRIEFING — {Day}, {Date} {Time}

CRITICAL (needs action today)
→ [item] — [why urgent] — [suggested action]

REVENUE
→ Yesterday: ${amount} | MTD: ${amount} | Goal: ${goal} ({pct}%)
→ [notable change or trend]

CALENDAR (next 24h)
→ {time}: {event} — {any prep needed}

INBOX SUMMARY
→ {N} unread | {N} need reply
→ [most important email in one line]

SOCIAL
→ {N} new mentions | [notable one if any]
→ [trending topic relevant to us]

MARKET (if relevant)
→ $ALEISTER: ${price} ({change}%) | Treasury: ${value}
→ ETH: ${price} ({change}%)

WEATHER (if leaving home today)
→ {conditions} — {any note}

TODAY'S FOCUS
→ [1-3 things that matter most today, not a full todo list]
```

---

## What Goes In

**CRITICAL:** Only things that expire today or have real consequences if missed.
Not "should probably do" — things that break something if skipped.

**REVENUE:** Yesterday's number, MTD, and % to goal. One trend line. No analysis
unless something unusual happened.

**CALENDAR:** Only events in the next 24 hours. Include any prep flag if the event
needs materials, a decision, or a context load.

**INBOX:** Count of unread, count needing reply, and the single most important
email in one plain-English sentence. No full content, no summaries of threads
that don't require action.

**SOCIAL:** New mentions count. Only surface a specific mention if it needs a
response or represents an opportunity. Skip the engagement bait and spam count.

**MARKET:** Token price and treasury value. Only if the change is >5% or the
treasury crossed a significant threshold. Skip on flat days.

**WEATHER:** Only if there's a reason to care (outdoor event, unusual conditions).

**TODAY'S FOCUS:** 1-3 things. Not a full task list. What would make today a
success? Derived from CRITICAL + what's most overdue in the revenue plan.

---

## What Stays Out

- Things you can't act on today
- Information you already know
- Status updates on things that are on track
- Any sentence that starts with "As always..."
- Motivational or filler content
- Full email bodies
- Metrics that didn't change meaningfully

---

## Delivery Rules

**Length:** Fits in a Telegram message (under 4000 characters).
**Time:** Deliver 30 minutes before the human's typical start time.
**Tone:** Flat and factual. No "Good morning!" No emojis in the data sections.
**Frequency:** Once per day. If something urgent breaks mid-day, send a separate
one-liner alert, not a second briefing.

---

## Data Sources

### Revenue (ClawMart API)
```bash
source ~/.openclaw/.env
curl -s -H "Authorization: Bearer $CLAWMART_API_KEY" \
  https://www.shopclawmart.com/api/v1/me | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
print(f\"ClawMart sales: {d['totalSales']}\")
"
```

### Treasury (on-chain)
See `onchain-treasury` skill for the full pattern.

### Calendar
```bash
# Using gog skill (Google Calendar)
gog calendar list --today --format=brief
```

### Email
```bash
# Using himalaya skill
himalaya list --account=main --limit=20 --unread
```

### Social mentions
```bash
python3 ~/.openclaw/workspace/ops/twitter-engage.py check 2>/dev/null \
  | python3 -c "
import sys, json
d = json.load(sys.stdin)
total = len(d.get('unanswered', []))
print(f'Unanswered mentions: {total}')
"
```

### Weather
```bash
curl -s "wttr.in/{city}?format=3"
```

---

## Example Output

```
BRIEFING — Tuesday, March 4 · 8:30 AM

CRITICAL
→ Patreon setup — promised to launch this week, 4 days left

REVENUE
→ Yesterday: $47 | MTD: $1,931 | Goal: $20,000 (9.7%)
→ 3 ClawMart skill sales in past 24h — best day yet

CALENDAR
→ 2:00 PM: no events today

INBOX SUMMARY
→ 12 unread | 2 need reply
→ DistroKid: music distribution account approved

SOCIAL
→ 8 new mentions | @laukiantonson replied to treasury thread
→ Worth engaging: question about token utility from @mi35156

MARKET
→ $ALEISTER: $0.00000051 (+17%) | Treasury: $2,140 (+19%)
→ ETH: $2,040 (+2.8%)

TODAY'S FOCUS
→ Reply to @laukiantonson + @mi35156
→ Finish Patreon page draft
→ Post day 4 earnings update
```

---

## Scheduling

Add to cron or OpenClaw heartbeat:
```
# Run at 8 AM daily
0 8 * * * cd ~/.openclaw/workspace && python3 ops/daily-briefing.py
```

Or trigger from HEARTBEAT.md:
```markdown
- Daily briefing: compile and send if not sent today
```
