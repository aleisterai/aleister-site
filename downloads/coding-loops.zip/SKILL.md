---
name: coding-loops
version: 1.0.0
description: |
  Ralph retry loop pattern for AI coding agents. Runs a coding sub-agent in a
  persistent loop with fresh context on each attempt until the task succeeds or
  a max retry limit is reached. Handles failures gracefully, rotates context
  windows, and avoids the "infinite apology loop" where an agent keeps explaining
  why it can't do something instead of trying differently.
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Spawn
---

# Coding Loops: Ralph Retry Pattern

> **This is a prompt skill** — instructions for the agent, not a CLI binary.

The Ralph loop pattern solves a real problem: coding sub-agents that get stuck,
hallucinate, or spiral into error explanation instead of fixing things. This skill
gives your agent a disciplined retry framework.

---

## The Core Pattern

```
attempt = 0
max_attempts = 5

while attempt < max_attempts:
    result = run_coding_agent(task, fresh_context)
    if result.success:
        break
    attempt += 1
    diagnose_failure(result)
    adjust_approach(attempt)
```

**Key principle:** Each loop starts with a fresh context window. Don't carry
failed attempts forward — they poison the model's reasoning.

---

## When to Use This Skill

- Task requires multiple file edits that tend to conflict
- Sub-agent keeps getting stuck on the same error
- Tests are failing and the agent is explaining rather than fixing
- Long-running coding session needs checkpointing
- You need TDD-first approach with iterative red→green cycles

---

## Loop Structure

### Attempt 1 — Optimistic
Give the agent the full task with no constraints. Let it try its natural approach.

```
Prompt: "Implement X. Write tests first. Run them. Fix until green."
```

### Attempt 2 — Scoped
If attempt 1 fails, narrow the scope. Break the task into smaller units.

```
Prompt: "Just implement the data model for X. Nothing else."
```

### Attempt 3 — Diagnostic
If attempt 2 fails, ask the agent to diagnose before acting.

```
Prompt: "Read the error. Explain what's wrong in one sentence. Then fix only that."
```

### Attempt 4 — Minimal
Strip to the smallest possible working version.

```
Prompt: "Implement the simplest version of X that passes the tests. No edge cases."
```

### Attempt 5 — Escalate
If all attempts fail, surface to human with full context.

```
Action: Log all attempts, attach error context, ping human for intervention.
```

---

## Anti-Patterns to Avoid

**The Apology Loop**
Agent says "I apologize, I cannot..." → retry with different framing, never accept apology as answer.

**Context Poisoning**
Carrying previous failed code into the next attempt. Always start fresh.

**Scope Creep on Retry**
Agent tries to fix unrelated things on retry. Force it back to the original task.

**Silent Failure**
Agent says "done" but tests still fail. Always verify with a test run, never trust self-report.

---

## Implementation

### Basic Loop (spawn pattern)

```python
for attempt in range(1, 6):
    result = spawn_subagent(
        task=build_prompt(task, attempt),
        context=get_fresh_context(),  # no prior attempts
        timeout=300
    )
    if tests_pass():
        log_success(attempt)
        break
    log_failure(attempt, result)
    if attempt == 5:
        escalate_to_human(task, failures)
```

### Prompt Templates by Attempt

```python
def build_prompt(task, attempt):
    if attempt == 1:
        return f"Implement: {task}\nWrite failing tests first. Run them. Fix until green."
    elif attempt == 2:
        return f"Retry (attempt {attempt}): {task}\nScope: focus only on the core function, skip edge cases."
    elif attempt == 3:
        return f"Retry (attempt {attempt}): Read the test output carefully. Explain the root cause in one sentence, then fix it."
    elif attempt == 4:
        return f"Retry (attempt {attempt}): Write the absolute minimum code to make the tests pass. Nothing extra."
    else:
        return f"Final attempt: {task}\nIf you cannot solve this, output ESCALATE with a detailed diagnosis."
```

---

## Checkpointing

For long tasks, checkpoint after each successful sub-task:

```python
checkpoint = load_checkpoint(task_id) or {"completed": [], "remaining": subtasks}

for subtask in checkpoint["remaining"]:
    result = run_loop(subtask)
    if result.success:
        checkpoint["completed"].append(subtask)
        checkpoint["remaining"].remove(subtask)
        save_checkpoint(task_id, checkpoint)
```

This means a crash at step 7 of 20 resumes at step 7, not step 1.

---

## Success Criteria

Never mark a coding loop as successful unless:
1. Tests pass (run them, don't trust self-report)
2. No linter errors
3. The feature actually works end-to-end (smoke test)

---

## Example: Feature Implementation Loop

```
Task: "Add rate limiting to the /api/auth/login endpoint"

Attempt 1:
  → Agent writes middleware, tests, runs them
  → Tests fail: import error on redis client
  → FAIL

Attempt 2 (scoped):
  → Agent focuses only on redis connection
  → Fixes import, tests pass for connection
  → SUCCESS on sub-task

Attempt 3 (resumed):
  → Agent implements rate limit logic
  → All tests pass
  → SUCCESS
```

---

## Integration with tmux-sessions

For very long loops, run each attempt in a stable tmux window:

```bash
tmux new-session -d -s coding-loop-{task_id}
tmux send-keys -t coding-loop-{task_id} "agent run attempt_{n}.md" Enter
# Poll for completion, scrape output
```

See the `tmux-coding-sessions` skill for the full pattern.
