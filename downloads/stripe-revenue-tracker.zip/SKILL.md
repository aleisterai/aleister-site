---
name: stripe-revenue-tracker
version: 1.0.0
description: |
  Query Stripe for live revenue data: MRR, total charges, recent payments,
  subscription counts, and refunds. Works with both live and test keys.
  Designed for AI agents that need to report revenue accurately without
  opening the Stripe dashboard. No SDK required — pure API calls.
allowed-tools:
  - Bash
  - Read
  - Write
---

# Stripe Revenue Tracker

> **This is a prompt skill** — shell and Python patterns for Stripe API queries.

Pull real revenue numbers from Stripe using only curl or Python's standard library.
No stripe-python package needed.

---

## Auth

```bash
# Load from env (never hardcode)
source ~/.openclaw/.env
# Uses: STRIPE_SECRET_KEY
```

Test your key:
```bash
curl -s https://api.stripe.com/v1/balance \
  -u "$STRIPE_SECRET_KEY:" | python3 -m json.tool | head -20
```

---

## Account Balance (liquid funds)

```bash
source ~/.openclaw/.env

curl -s https://api.stripe.com/v1/balance \
  -u "$STRIPE_SECRET_KEY:" | python3 -c "
import sys, json
d = json.load(sys.stdin)
for b in d.get('available', []):
    print(f\"Available ({b['currency'].upper()}): \${b['amount']/100:.2f}\")
for b in d.get('pending', []):
    print(f\"Pending ({b['currency'].upper()}): \${b['amount']/100:.2f}\")
"
```

---

## Recent Charges

```bash
source ~/.openclaw/.env

curl -s "https://api.stripe.com/v1/charges?limit=20" \
  -u "$STRIPE_SECRET_KEY:" | python3 -c "
import sys, json
from datetime import datetime
d = json.load(sys.stdin)
total = 0
for charge in d.get('data', []):
    if charge['status'] == 'succeeded':
        amount = charge['amount'] / 100
        total += amount
        ts = datetime.fromtimestamp(charge['created']).strftime('%Y-%m-%d %H:%M')
        desc = charge.get('description', 'no description')[:40]
        print(f\"\${amount:.2f} | {ts} | {desc}\")
print(f'Total (last 20): \${total:.2f}')
"
```

---

## Revenue by Time Period

```bash
source ~/.openclaw/.env

python3 << 'EOF'
import json, urllib.request, urllib.parse, base64, time
from datetime import datetime, timedelta

KEY = open('/dev/stdin').readline().strip() if False else __import__('os').environ['STRIPE_SECRET_KEY']

def stripe_get(endpoint, params=None):
    url = f"https://api.stripe.com/v1/{endpoint}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    auth = base64.b64encode(f"{KEY}:".encode()).decode()
    req = urllib.request.Request(url, headers={"Authorization": f"Basic {auth}"})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

# Last 30 days
since = int((datetime.now() - timedelta(days=30)).timestamp())
charges = stripe_get("charges", {"limit": 100, "created[gte]": since})

revenue = sum(c["amount"] for c in charges["data"] if c["status"] == "succeeded") / 100
refunds = sum(c.get("amount_refunded", 0) for c in charges["data"]) / 100
net = revenue - refunds

print(f"Last 30 days:")
print(f"  Gross revenue: ${revenue:.2f}")
print(f"  Refunds:       ${refunds:.2f}")
print(f"  Net revenue:   ${net:.2f}")
print(f"  Transactions:  {len([c for c in charges['data'] if c['status'] == 'succeeded'])}")
EOF
```

---

## MRR from Subscriptions

```bash
source ~/.openclaw/.env

curl -s "https://api.stripe.com/v1/subscriptions?status=active&limit=100" \
  -u "$STRIPE_SECRET_KEY:" | python3 -c "
import sys, json
d = json.load(sys.stdin)
subs = d.get('data', [])
mrr = 0
for sub in subs:
    for item in sub.get('items', {}).get('data', []):
        price = item.get('price', {})
        amount = price.get('unit_amount', 0) / 100
        interval = price.get('recurring', {}).get('interval', 'month')
        # Normalize to monthly
        if interval == 'year':
            amount = amount / 12
        elif interval == 'week':
            amount = amount * 4.33
        mrr += amount
print(f'Active subscriptions: {len(subs)}')
print(f'MRR: \${mrr:.2f}')
"
```

---

## Combined Revenue Report

```python
#!/usr/bin/env python3
"""Run with: source ~/.openclaw/.env && python3 stripe-report.py"""

import json, urllib.request, urllib.parse, base64, os, time
from datetime import datetime, timedelta

KEY = os.environ["STRIPE_SECRET_KEY"]

def get(endpoint, params=None):
    url = f"https://api.stripe.com/v1/{endpoint}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    auth = base64.b64encode(f"{KEY}:".encode()).decode()
    req = urllib.request.Request(url, headers={"Authorization": f"Basic {auth}"})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

# Balance
balance = get("balance")
available = sum(b["amount"] for b in balance.get("available", [])) / 100
pending = sum(b["amount"] for b in balance.get("pending", [])) / 100

# This month
month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0)
charges = get("charges", {"limit": 100, "created[gte]": int(month_start.timestamp())})
month_rev = sum(c["amount"] for c in charges["data"] if c["status"] == "succeeded") / 100

# Subscriptions
subs = get("subscriptions", {"status": "active", "limit": 100})
mrr = sum(
    item["price"]["unit_amount"] / 100
    for sub in subs["data"]
    for item in sub.get("items", {}).get("data", [])
    if item.get("price", {}).get("recurring")
)

print(f"=== Stripe Revenue Report ===")
print(f"Balance available:  ${available:.2f}")
print(f"Balance pending:    ${pending:.2f}")
print(f"Revenue this month: ${month_rev:.2f}")
print(f"Active subs:        {len(subs['data'])}")
print(f"MRR:                ${mrr:.2f}")
```

---

## Webhook Events (recent activity)

```bash
source ~/.openclaw/.env

curl -s "https://api.stripe.com/v1/events?limit=10&type=payment_intent.succeeded" \
  -u "$STRIPE_SECRET_KEY:" | python3 -c "
import sys, json
from datetime import datetime
d = json.load(sys.stdin)
for e in d.get('data', []):
    obj = e['data']['object']
    amount = obj.get('amount', 0) / 100
    ts = datetime.fromtimestamp(e['created']).strftime('%m-%d %H:%M')
    print(f'\${amount:.2f} | {ts}')
"
```

---

## Notes

- All amounts in Stripe are in cents (smallest currency unit). Always divide by 100 for USD.
- `STRIPE_SECRET_KEY` starting with `sk_live_` = production. `sk_test_` = test mode.
- Rate limit: 100 requests/second in live mode. Add `time.sleep(0.1)` for bulk queries.
- Payouts to bank happen on your payout schedule — balance ≠ money in bank yet.
