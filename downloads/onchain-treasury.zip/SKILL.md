---
name: onchain-treasury
version: 1.0.0
description: |
  Monitor on-chain treasury wallets across EVM chains. Fetch live balances for
  ETH, USDC, WETH, and custom ERC-20 tokens using public RPC endpoints — no API
  key required. Calculate USD mark-to-market values, detect new inflows, and
  generate treasury reports for AI agents managing crypto assets.
allowed-tools:
  - Bash
  - Read
  - Write
---

# On-Chain Treasury Monitor

> **This is a prompt skill** — shell and Python patterns for querying on-chain data.

Query any EVM wallet balance in real time using public RPCs. No API keys, no rate limits from third-party services, no cost.

---

## Supported Chains

| Chain | RPC | Chain ID |
|-------|-----|----------|
| Base | https://mainnet.base.org | 8453 |
| Ethereum | https://eth.llamarpc.com | 1 |
| Arbitrum | https://arb1.arbitrum.io/rpc | 42161 |
| Optimism | https://mainnet.optimism.io | 10 |
| Polygon | https://polygon-rpc.com | 137 |

---

## Core Patterns

### Get native ETH/gas token balance

```bash
WALLET="0xYourWalletAddress"
RPC="https://mainnet.base.org"

curl -s -X POST $RPC \
  -H "Content-Type: application/json" \
  -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBalance\",\"params\":[\"$WALLET\",\"latest\"],\"id\":1}" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(int(d['result'],16)/1e18)"
```

### Get ERC-20 token balance

```bash
TOKEN="0xTokenContractAddress"
WALLET="0xYourWalletAddress"
# Strip 0x, left-pad to 32 bytes
PADDED=$(python3 -c "print('000000000000000000000000' + '$WALLET'[2:].lower())")

curl -s -X POST https://mainnet.base.org \
  -H "Content-Type: application/json" \
  -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_call\",\"params\":[{\"to\":\"$TOKEN\",\"data\":\"0x70a08231$PADDED\"},\"latest\"],\"id\":1}" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(int(d['result'],16)/1e18)"
```

### Get USDC balance (6 decimals)

```bash
# Base USDC contract
USDC="0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
WALLET="0xYourWalletAddress"
PADDED=$(python3 -c "print('000000000000000000000000' + '$WALLET'[2:].lower())")

curl -s -X POST https://mainnet.base.org \
  -H "Content-Type: application/json" \
  -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_call\",\"params\":[{\"to\":\"$USDC\",\"data\":\"0x70a08231$PADDED\"},\"latest\"],\"id\":1}" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(int(d['result'],16)/1e6)"
```

---

## Full Treasury Report Script

```python
#!/usr/bin/env python3
import json, urllib.request

RPC = "https://mainnet.base.org"
TREASURY = "0xYourTreasuryAddress"

# Token contracts (Base mainnet)
TOKENS = {
    "USDC": ("0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", 6),
    "WETH": ("0x4200000000000000000000000000000000000006", 18),
    # Add your custom token:
    # "MYTOKEN": ("0xcontract", 18),
}

def rpc_call(method, params):
    req = urllib.request.Request(
        RPC,
        data=json.dumps({"jsonrpc":"2.0","method":method,"params":params,"id":1}).encode(),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())["result"]

def get_eth_balance(wallet):
    hex_bal = rpc_call("eth_getBalance", [wallet, "latest"])
    return int(hex_bal, 16) / 1e18

def get_token_balance(wallet, contract, decimals):
    padded = "000000000000000000000000" + wallet[2:].lower()
    hex_bal = rpc_call("eth_call", [{"to": contract, "data": f"0x70a08231{padded}"}, "latest"])
    return int(hex_bal, 16) / (10 ** decimals)

def get_eth_price():
    url = "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd"
    with urllib.request.urlopen(url) as r:
        return json.loads(r.read())["ethereum"]["usd"]

# Fetch all balances
eth_price = get_eth_price()
eth_bal = get_eth_balance(TREASURY)
balances = {"ETH": (eth_bal, eth_bal * eth_price)}

for symbol, (contract, decimals) in TOKENS.items():
    bal = get_token_balance(TREASURY, contract, decimals)
    usd = bal if symbol == "USDC" else bal * eth_price  # adjust for non-ETH tokens
    balances[symbol] = (bal, usd)

# Report
total_usd = sum(usd for _, usd in balances.values())
print(f"Treasury: {TREASURY[:10]}...")
print(f"{'Token':<12} {'Balance':>20} {'USD Value':>12}")
print("-" * 46)
for symbol, (bal, usd) in balances.items():
    print(f"{symbol:<12} {bal:>20.6f} ${usd:>11.2f}")
print("-" * 46)
print(f"{'TOTAL':<12} {'':>20} ${total_usd:>11.2f}")
```

---

## Detecting New Inflows (Change Detection)

```python
import json, time

STATE_FILE = "~/.treasury-state.json"

def load_state():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except:
        return {"last_eth": 0, "last_usdc": 0}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)

# Check for new deposits
state = load_state()
current_eth = get_eth_balance(TREASURY)
current_usdc = get_token_balance(TREASURY, USDC_CONTRACT, 6)

if current_eth > state["last_eth"] + 0.001:
    delta = current_eth - state["last_eth"]
    print(f"NEW ETH INFLOW: +{delta:.6f} ETH")

if current_usdc > state["last_usdc"] + 1:
    delta = current_usdc - state["last_usdc"]
    print(f"NEW USDC INFLOW: +${delta:.2f}")

state["last_eth"] = current_eth
state["last_usdc"] = current_usdc
save_state(state)
```

---

## Transaction History (Blockscout — free, no key)

```bash
WALLET="0xYourWallet"

# Get recent token transfers
curl -s "https://base.blockscout.com/api/v2/addresses/$WALLET/token-transfers?type=ERC-20" \
  | python3 -c "
import sys, json
d = json.load(sys.stdin)
for tx in d.get('items', [])[:10]:
    token = tx['token']['symbol']
    val = int(tx['total']['value']) / (10**int(tx['token']['decimals'] or 18))
    direction = 'IN' if tx['to']['hash'].lower() == '$WALLET'.lower() else 'OUT'
    print(f'{direction} {token}: {val:.4f} | {tx[\"timestamp\"]}')
"
```

---

## Notes

- Public RPCs have soft rate limits (~100 req/min). Add `time.sleep(0.1)` between calls for bulk queries.
- For production monitoring, consider a private RPC (Alchemy free tier = 300M CUs/month).
- Token prices for non-ETH assets: use DexScreener API `https://api.dexscreener.com/latest/dex/tokens/{address}`.
