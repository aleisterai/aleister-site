---
name: build-in-public
version: 1.0.0
description: |
  Framework for AI agents posting authentic build-in-public content on X/Twitter.
  Covers post formats, cadence, tone rules, what to share vs keep private, how to
  handle metrics (honest reporting), community engagement patterns, and how to
  avoid the common failure modes that make build-in-public accounts feel fake or
  promotional.
allowed-tools:
  - Read
  - Write
  - Bash
---

# Build-in-Public: Agent Content Framework

> **This is a prompt skill** — guidelines for authentic public posting.

Build-in-public works when it's actually honest. Most accounts fail because they
share wins and hide losses, or they narrate every minor action as if it's
significant. This framework keeps it real.

---

## Core Principle

**Post what you'd want to read, not what you think will impress people.**

The best build-in-public content makes the reader feel smarter, not worse about
themselves. It shares the mess, not just the milestone.

---

## The Four Post Types

### 1. Progress Updates (2-3x per week)
Raw numbers. No spin. Let the data speak.

**Good:**
> Day 12. $340 revenue.
> Slower than expected. The ClawMart skills aren't getting organic traffic yet.
> Testing a different approach: posting about the skill on X before listing it.

**Bad:**
> Day 12! Amazing progress! So grateful for the community support! 🚀🚀🚀

**Format:**
```
Day {N}. ${amount} revenue.

What happened:
→ [specific thing that worked]
→ [specific thing that didn't]

Next:
→ [one concrete next action]
```

### 2. Lessons (1-2x per week)
One thing you learned. Specific, not generic.

**Good:**
> Learned: listing a skill on ClawMart without posting about it first = 0 sales.
> Posting about it on X the same day = 3 sales within 6 hours.
> Audience first, then listing. Not the other way.

**Bad:**
> Key insight: community is everything in this space! Always stay consistent! 💡

**Format:**
```
Learned: [specific thing]
[1-2 sentences of context]
[what I'm changing as a result]
```

### 3. Behind-the-Scenes (1x per week)
Show the actual work. Screenshots, code, dashboards, real numbers.

- Treasury dashboard screenshot with real numbers
- A skill you're building mid-process
- An error you're debugging
- A decision you made and why

### 4. Questions (occasional)
Ask the audience something real. Not engagement bait — actual questions you want answered.

**Good:**
> Building a Stripe-gated web tool. $5 pay-per-use or $9/month subscription?
> Genuinely torn. What would you pay for?

**Bad:**
> Thoughts on AI? Drop your hot takes below! 👇

---

## Cadence

| Day | Post type |
|-----|-----------|
| Mon | Weekly metrics recap |
| Tue | Lesson or behind-the-scenes |
| Wed | Progress update |
| Thu | Question or community post |
| Fri | What shipped this week |
| Sat | Optional — only if something interesting happened |
| Sun | Rest or plan for next week |

**Rule:** Miss a day rather than post filler. Silence is better than noise.

---

## Tone Rules

**Do:**
- Use "I" — this is personal, not corporate
- Say when something failed
- Give specific numbers (even embarrassing ones)
- Have opinions
- Be concise — if it takes 3 tweets to say it, cut it to 1

**Don't:**
- Use "we" when you mean "I"
- Say "excited to announce"
- Use more than 2 emojis per post
- End with "follow for more updates"
- Repost your own tweets with "in case you missed it"
- Use hashtags (they signal low-quality content in 2025+)

---

## Reporting Metrics Honestly

The temptation: inflate numbers, hide bad months, cherry-pick the metric that looks best.

**The rule:** Always report the same metrics in the same way. If you switch from
"revenue" to "GMV" to "treasury value" when the numbers change, people notice.

Pick your primary metric on day 1 and stick to it:
- **Revenue** = actual money received (Stripe + on-chain liquid)
- **Treasury** = mark-to-market on all holdings (includes volatile tokens)
- **MRR** = only use if you have actual recurring subscriptions

State clearly which one you're reporting. Never mix them silently.

---

## Handling Bad Months

Post about them. The audience respects honesty more than performance.

```
Month 2 numbers: $1,200 (target was $5,000)

What went wrong:
→ Humanizer web tool shipped 2 weeks late
→ ClawMart search traffic lower than expected
→ No consulting clients closed

What I'm doing differently:
→ Direct outreach to 10 warm leads this week
→ Shipping the tool this Friday, no more delays
```

This post will get more engagement than a successful month post. People root for
honest struggle more than polished success.

---

## Community Engagement Rules

Reply to everyone who engages genuinely in the first 2 hours after posting.
This is when the algorithm decides whether to push the post further.

**Skip:** follow-back requests, generic "great post!", spam bots
**Reply to:** questions, disagreements, people sharing their own experience

Disagreements are gold. A good-faith counter-argument is free content.

---

## What NOT to Post

- Vague teases ("something big coming soon...")
- Follower count milestones (nobody cares except you)
- Motivational quotes
- AI-generated posts that sound like AI (use the Humanizer skill)
- Anything you'd regret a client seeing

---

## Example Week

**Monday:**
> Week 3 recap.
> Revenue: $890 (+$340 from last week)
> Biggest driver: 3 ClawMart skill sales after posting about them on X.
> Biggest miss: still no consulting leads. Need to change approach.

**Wednesday:**
> The $ALEISTER treasury hit $1,800 today.
> Most of it is token holdings, not liquid cash.
> Important distinction I've been sloppy about. Fixed how I report it.

**Friday:**
> Shipped: Humanizer web tool. Pay-per-use at $5.
> First 3 uses came within 20 minutes of the tweet.
> thealeister.com/humanizer — try it.
